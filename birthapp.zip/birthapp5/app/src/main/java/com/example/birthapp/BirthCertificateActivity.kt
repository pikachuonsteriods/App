package com.example.birthapp

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.Toast
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import io.appwrite.Client
import android.content.Intent
import io.appwrite.services.Storage
import io.appwrite.services.Databases
import io.appwrite.ID
import io.appwrite.Query
import io.appwrite.models.InputFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import android.content.ContentResolver

class BirthCertificateActivity : ComponentActivity() {
    private lateinit var client: Client
    private lateinit var storage: Storage
    private lateinit var database: Databases

    private var selectedFileUri: Uri? = null
    private lateinit var filePickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set the content view to the XML layout
        setContentView(R.layout.activity_birth_certificate)

        // Initialize the Appwrite client
        client = Client(this)
            .setEndpoint("https://cloud.appwrite.io/v1") // Your Appwrite endpoint
            .setProject("66f45171002bbc202722") // Your Appwrite Project ID

        storage = Storage(client)
        database = Databases(client)

        // Set up button click listeners
        val selectButton: Button = findViewById(R.id.select)
        val uploadButton: Button = findViewById(R.id.upload)

        selectButton.setOnClickListener { selectFile() }
        uploadButton.setOnClickListener { uploadDocument() }

        filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                selectedFileUri = result.data?.data
                Log.d("FilePicker", "File selected: ${selectedFileUri.toString()}")
                Toast.makeText(this, "File selected", Toast.LENGTH_SHORT).show()
            } else {
                Log.d("FilePicker", "File selection failed or canceled")
                Toast.makeText(this, "File selection failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*" // You can change this to filter for specific types (e.g., "image/*")
        }
        filePickerLauncher.launch(intent)
    }

    private fun uploadDocument() {
        val uri = selectedFileUri ?: run {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show()
            Log.d("Upload", "No file selected")
            return
        }

        try {
            val inputStream = contentResolver.openInputStream(uri)
            inputStream?.let {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        // Step 2: Hash the selected image file
                        val fileHash = hashFile(uri)
                        Log.d("Upload", "Generated Hash for the image: $fileHash")  // Display the generated hash in the logs

                        // Step 3: Compare hash with the database
                        val hashExists = isHashExistsInDatabase(fileHash)
                        if (hashExists) {
                            // Step 4: If the hash exists, proceed with the file upload
                            val fileName = getFileName(uri)
                            val tempFile = File.createTempFile("upload_", fileName)
                            tempFile.outputStream().use { output -> inputStream.copyTo(output) }

                            val file = InputFile.fromFile(tempFile)
                            val response = storage.createFile("66f5141a002a27027069", ID.unique(), file)

                            runOnUiThread {
                                Log.d("Upload", "File uploaded successfully")
                                Toast.makeText(this@BirthCertificateActivity, "File uploaded successfully!", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // Step 5: If the hash doesn't exist, don't upload the file
                            runOnUiThread {
                                Toast.makeText(this@BirthCertificateActivity, "Image hash not found in database! Not uploading.", Toast.LENGTH_SHORT).show()
                                Log.d("Upload", "Hash not found in database. Not uploading file.")
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Log.e("Upload", "Error during file upload: ${e.message}")
                            Toast.makeText(this@BirthCertificateActivity, "File upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("Upload", "Error opening file: ${e.message}")
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hashFile(uri: Uri): String {
        val inputStream = contentResolver.openInputStream(uri)
        val digest = MessageDigest.getInstance("SHA-256")
        inputStream?.let {
            val buffer = ByteArray(1024)
            var bytesRead: Int
            while (it.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        val hashedBytes = digest.digest()
        return hashedBytes.joinToString("") { "%02x".format(it) }
    }

    private suspend fun isHashExistsInDatabase(fileHash: String): Boolean {
        var hashExists = false
        try {
            // Now this is a suspend function
            val response = withContext(Dispatchers.IO) {
                database.listDocuments(
                    databaseId = "66f45171002bbc202722",  // Your correct database ID
                    collectionId = "67307475003b117e6b9b",  // Replace with your actual collection ID
                    queries = listOf(Query.equal("hash", fileHash)) // Query to check for hash
                )
            }
            hashExists = response.documents.isNotEmpty()
            Log.d("Database", "Hash found in database: $hashExists")  // Log whether the hash was found
        } catch (e: Exception) {
            Log.e("Database", "Error checking for hash in the database: ${e.message}")
        }
        return hashExists
    }

    private fun getFileName(uri: Uri): String {
        val resolver: ContentResolver = contentResolver
        val cursor = resolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            it.moveToFirst()
            return it.getString(nameIndex)
        }
        return uri.path ?: "unknown_file"
    }
}
