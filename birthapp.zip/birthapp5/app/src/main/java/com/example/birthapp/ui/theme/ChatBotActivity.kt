package com.example.birthapp

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.widget.ScrollView
import android.graphics.drawable.Drawable
import android.widget.LinearLayout.LayoutParams
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat

class ChatBotActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Create a vertical LinearLayout to hold the UI components
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(16, 16, 16, 16)  // Adding padding to the layout

        // Create a ScrollView to make the UI scrollable (if content overflows)
        val scrollView = ScrollView(this)
        scrollView.addView(layout)

        // Set the scrollable view as the content view
        setContentView(scrollView)

        // Create a TextView to display the chatbot response
        val chatResponseText = TextView(this)
        chatResponseText.text = "Welcome to the Chatbot!"
        chatResponseText.textSize = 20f
        chatResponseText.gravity = Gravity.CENTER
        chatResponseText.setTextColor(resources.getColor(android.R.color.black))
        chatResponseText.setPadding(16, 16, 16, 16)
        layout.addView(chatResponseText)

        // Create Buttons for predefined questions
        val buttonStyle = ResourcesCompat.getDrawable(resources, R.drawable.button_background, null)  // Button background style

        val chatButton1 = Button(this)
        chatButton1.text = "I couldn't upload the document"
        chatButton1.setBackgroundDrawable(buttonStyle)
        chatButton1.setTextColor(resources.getColor(android.R.color.white))
        chatButton1.textSize = 16f
        chatButton1.setPadding(24, 16, 24, 16)
        layout.addView(chatButton1)

        val chatButton2 = Button(this)
        chatButton2.text = "I didn't get the birth certificate"
        chatButton2.setBackgroundDrawable(buttonStyle)
        chatButton2.setTextColor(resources.getColor(android.R.color.white))
        chatButton2.textSize = 16f
        chatButton2.setPadding(24, 16, 24, 16)
        layout.addView(chatButton2)

        val chatButton3 = Button(this)
        chatButton3.text = "How do I download my document?"
        chatButton3.setBackgroundDrawable(buttonStyle)
        chatButton3.setTextColor(resources.getColor(android.R.color.white))
        chatButton3.textSize = 16f
        chatButton3.setPadding(24, 16, 24, 16)
        layout.addView(chatButton3)

        val chatButton4 = Button(this)
        chatButton4.text = "How do I contact support?"
        chatButton4.setBackgroundDrawable(buttonStyle)
        chatButton4.setTextColor(resources.getColor(android.R.color.white))
        chatButton4.textSize = 16f
        chatButton4.setPadding(24, 16, 24, 16)
        layout.addView(chatButton4)

        val chatButton5 = Button(this)
        chatButton5.text = "How long does it take to process my request?"
        chatButton5.setBackgroundDrawable(buttonStyle)
        chatButton5.setTextColor(resources.getColor(android.R.color.white))
        chatButton5.textSize = 16f
        chatButton5.setPadding(24, 16, 24, 16)
        layout.addView(chatButton5)

        // Set OnClickListeners for the buttons
        chatButton1.setOnClickListener {
            chatResponseText.text = "Answer: The document should be below 5 MB. Please check the file size and try uploading again."
        }

        chatButton2.setOnClickListener {
            chatResponseText.text = "Answer: Please send us a detailed email describing your issue, and we’ll provide further assistance."
        }

        chatButton3.setOnClickListener {
            chatResponseText.text = "Answer: After uploading the documents, please allow 21 days for processing. Once it’s ready, you’ll receive the document via email."
        }

        chatButton4.setOnClickListener {
            chatResponseText.text = "Answer: Please email our support team at [support@example.com] with your query, and we’ll get back to you soon. Alternatively, you can call us at 0801234567."
        }

        chatButton5.setOnClickListener {
            chatResponseText.text = "Answer: The processing time may vary, but most requests are completed within 21-30 days."
        }
    }
}
